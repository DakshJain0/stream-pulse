import { ObservationData } from '../../types/stream';

export interface WizardQuestionConfig {
  id: keyof ObservationData | 'notes';
  category: string;
  title: string;
  subtitle: string;
  plainLanguagePrompt: string;
  options: {
    value: string | number;
    label: string;
    icon: string;
    description: string;
  }[];
}

/**
 * 5-Screen Plain-Language Stream-Check Questions
 * Modeled on EPA Volunteer Stream Visual Assessment Protocol and CreekWatch:
 * Screen 1: Water Appearance
 * Screen 2: Stream Banks & Shoreline
 * Screen 3: Water Flow Level
 * Screen 4: Water Odor & Surface / Wildlife Signs
 * Screen 5: Overall Stream Rating (1 to 5 Stars)
 */
export const STREAM_CHECK_QUESTIONS: WizardQuestionConfig[] = [
  {
    id: 'waterAppearance',
    category: 'Screen 1 of 5',
    title: 'Water Appearance',
    subtitle: 'Look closely at the water clarity and surface film.',
    plainLanguagePrompt: 'What does the stream water look like today?',
    options: [
      {
        value: 'Clear',
        label: 'Clear & Transparent',
        icon: '💧',
        description: 'You can clearly see the pebbles and bottom of the stream with no murkiness.',
      },
      {
        value: 'Tea-Colored',
        label: 'Tea-Colored / Tannin',
        icon: '🍂',
        description: 'Naturally tinted brownish from fallen leaves, but clean and transparent.',
      },
      {
        value: 'Turbid / Muddy',
        label: 'Cloudy Mud or Silt',
        icon: '🌫️',
        description: 'Water is opaque with brown or gray sediment from recent rain or erosion.',
      },
      {
        value: 'Foamy / Scummy',
        label: 'Foam or Green Scum',
        icon: '🧼',
        description: 'Persistent bubbly froth or thick green algae mats floating on top.',
      },
      {
        value: 'Oily Sheen',
        label: 'Oily / Rainbow Sheen',
        icon: '⛽',
        description: 'A colorful iridescent sheen that stays together when poked (petroleum/runoff).',
      },
    ],
  },
  {
    id: 'streamBanks',
    category: 'Screen 2 of 5',
    title: 'Stream Banks & Buffers',
    subtitle: 'Check the soil, plants, and trees lining both sides of the stream.',
    plainLanguagePrompt: 'How healthy and stable are the stream banks?',
    options: [
      {
        value: 'Stable & Vegetated',
        label: 'Stable & Covered in Plants',
        icon: '🌿',
        description: 'Healthy native grass, shrubs, and trees securely holding the shoreline soil.',
      },
      {
        value: 'Minor Erosion',
        label: 'Minor Exposed Roots / Soil Slumping',
        icon: '🌱',
        description: 'A few exposed roots or small patches of bare mud crumbling into the water.',
      },
      {
        value: 'Severe Erosion',
        label: 'Severe Bank Collapse',
        icon: '⚠️',
        description: 'Steep bare dirt cliffs, falling trees, or large chunks of bank washed away.',
      },
      {
        value: 'Artificially Armored',
        label: 'Concrete Channel or Rock Wall',
        icon: '🧱',
        description: 'Engineered concrete culverts, stone baskets, or rock riprap line the edges.',
      },
    ],
  },
  {
    id: 'flowLevel',
    category: 'Screen 3 of 5',
    title: 'Water Flow Level',
    subtitle: 'Estimate how much water is flowing through the channel right now.',
    plainLanguagePrompt: 'How fast and high is the water running?',
    options: [
      {
        value: 'Normal Baseflow',
        label: 'Normal Flow',
        icon: '🌊',
        description: 'Water is moving at a steady, typical seasonal pace and normal depth.',
      },
      {
        value: 'Low / Trickle',
        label: 'Low Trickle / Separated Pools',
        icon: '🪨',
        description: 'Very shallow flow or isolated puddles with dry gravel patches exposed.',
      },
      {
        value: 'Dry Streambed',
        label: 'Completely Dry',
        icon: '☀️',
        description: 'No surface water flowing through this section of the creek bed today.',
      },
      {
        value: 'High / Swift Stormflow',
        label: 'High & Fast Surge',
        icon: '⚡',
        description: 'Water is swollen and rushing quickly after recent storms or heavy rain.',
      },
      {
        value: 'Over-Bank Flooding',
        label: 'Over-Bank Flood',
        icon: '🚨',
        description: 'Water has spilled out of the channel onto pedestrian trails, parks, or streets.',
      },
    ],
  },
  {
    id: 'additionalObservation',
    category: 'Screen 4 of 5',
    title: 'Odor & Stream Corridor Life',
    subtitle: 'Sniff the air and watch for wildlife or debris in the water.',
    plainLanguagePrompt: 'Do you notice any distinct odors or signs of life?',
    options: [
      {
        value: 'Natural & Wildlife Present',
        label: 'Fresh Scent + Active Wildlife',
        icon: '🐟',
        description: 'Clean earthy smell; minnows, turtles, dragonflies, or water birds active.',
      },
      {
        value: 'No Noticeable Odor',
        label: 'Clean / No Noticeable Smell',
        icon: '🍃',
        description: 'Neutral outdoor baseline with no chemical or foul odor.',
      },
      {
        value: 'Sewage / Rotten Egg Odor',
        label: 'Sewage or Rotten Eggs',
        icon: '🦨',
        description: 'Strong sulfur or septic odor indicating potential sewer pipe leakage.',
      },
      {
        value: 'Chemical / Chlorine Odor',
        label: 'Chemical / Fuel / Bleach',
        icon: '🧪',
        description: 'Pungent gasoline, chlorine, or solvent odor requiring immediate attention.',
      },
      {
        value: 'Heavy Litter & Debris',
        label: 'Heavy Trash & Plastic Litter',
        icon: '🗑️',
        description: 'Multiple bottles, bags, cans, or tires caught in the stream channel.',
      },
    ],
  },
  {
    id: 'overallRating',
    category: 'Screen 5 of 5',
    title: 'Overall Stream Rating',
    subtitle: 'Bring together all your observations into a final score for this reach.',
    plainLanguagePrompt: 'What is your overall health rating for this stream today?',
    options: [
      {
        value: 5,
        label: '⭐⭐⭐⭐⭐ 5 - Excellent',
        icon: '🌟',
        description: 'Pristine creek, sparkling water, thriving wildlife, intact natural banks.',
      },
      {
        value: 4,
        label: '⭐⭐⭐⭐ 4 - Good',
        icon: '🟢',
        description: 'Healthy urban waterway with only minor signs of human or runoff impact.',
      },
      {
        value: 3,
        label: '⭐⭐⭐ 3 - Fair',
        icon: '🟡',
        description: 'Noticeable sediment, minor erosion, or light trash, but functioning ecology.',
      },
      {
        value: 2,
        label: '⭐⭐ 2 - Poor',
        icon: '🟠',
        description: 'Heavily clouded water, bank breakdown, unpleasant odor, or heavy litter.',
      },
      {
        value: 1,
        label: '⭐ 1 - Very Poor / Alert',
        icon: '🔴',
        description: 'Critical contamination, active toxic spill, or severe environmental danger.',
      },
    ],
  },
];
