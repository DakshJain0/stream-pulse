import { Stream, ObservationData, ObservationRecord, StreamStatus } from '../types/stream';

// Initial mock streams for adopted urban streams
const INITIAL_STREAMS: Stream[] = [
  {
    id: 'stream-1',
    name: 'Willow Creek - Reach 4',
    location: 'Northgate Park Urban Greenway',
    watershed: 'Lower Cedar Basin',
    status: 'green',
    lastCheckedDate: new Date(Date.now() - 12 * 86400000).toISOString(), // 12 days ago
    nextDueDate: new Date(Date.now() + 18 * 86400000).toISOString(),     // 18 days from now
    revisitStreak: 4,
    totalObservations: 4,
  },
  {
    id: 'stream-2',
    name: 'Cedar Run - Mid Reach',
    location: 'Elmwood Pedestrian Bridge',
    watershed: 'Upper Cedar River',
    status: 'amber',
    lastCheckedDate: new Date(Date.now() - 32 * 86400000).toISOString(), // 32 days ago (due soon)
    nextDueDate: new Date(Date.now() - 2 * 86400000).toISOString(),      // 2 days overdue
    revisitStreak: 2,
    totalObservations: 3,
  },
  {
    id: 'stream-3',
    name: 'Millrace Canal Urban Outfall',
    location: 'Industrial District Crossing',
    watershed: 'Harbor Tributary System',
    status: 'red',
    lastCheckedDate: new Date(Date.now() - 58 * 86400000).toISOString(), // 58 days ago (stale)
    nextDueDate: new Date(Date.now() - 28 * 86400000).toISOString(),
    revisitStreak: 0,
    totalObservations: 1,
  },
];

const STORAGE_KEY_STREAMS = 'streamkeeper_streams';
const STORAGE_KEY_OBSERVATIONS = 'streamkeeper_observations';

class StreamStore {
  private streams: Stream[] = [];
  private observations: ObservationRecord[] = [];
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    if (typeof window === 'undefined') {
      this.streams = INITIAL_STREAMS;
      return;
    }

    try {
      const storedStreams = localStorage.getItem(STORAGE_KEY_STREAMS);
      const storedObs = localStorage.getItem(STORAGE_KEY_OBSERVATIONS);

      if (storedStreams) {
        this.streams = JSON.parse(storedStreams);
        // Recalculate dynamic statuses based on current date
        this.recalculateStatuses();
      } else {
        this.streams = INITIAL_STREAMS;
        this.saveToStorage();
      }

      if (storedObs) {
        this.observations = JSON.parse(storedObs);
      }
    } catch {
      this.streams = INITIAL_STREAMS;
    }
  }

  private saveToStorage() {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY_STREAMS, JSON.stringify(this.streams));
      localStorage.setItem(STORAGE_KEY_OBSERVATIONS, JSON.stringify(this.observations));
    } catch (e) {
      console.error('Failed to save to localStorage', e);
    }
  }

  private recalculateStatuses() {
    const now = Date.now();
    this.streams.forEach((stream) => {
      const lastCheck = new Date(stream.lastCheckedDate).getTime();
      const diffDays = Math.floor((now - lastCheck) / (1000 * 60 * 60 * 24));

      if (diffDays <= 30) {
        stream.status = 'green';
      } else if (diffDays <= 45) {
        stream.status = 'amber';
      } else {
        stream.status = 'red';
      }
    });
  }

  /**
   * Evaluates the 30-day revisit streak.
   * - Streak increments when re-checked roughly on schedule (~every 30 days, window: 25 to 45 days)
   * - If first observation or overdue (>45 days): resets streak to 1
   * - If early re-check (< 25 days): keeps existing streak
   */
  private computeUpdatedStreak(currentStreak: number, lastCheckedIso: string, newCheckIso: string): number {
    if (!lastCheckedIso) return 1;

    const prevDate = new Date(lastCheckedIso).getTime();
    const currentDate = new Date(newCheckIso).getTime();
    const daysBetween = Math.round((currentDate - prevDate) / (1000 * 60 * 60 * 24));

    if (daysBetween >= 25 && daysBetween <= 45) {
      // Checked right on time (~monthly schedule)
      return currentStreak + 1;
    } else if (daysBetween > 45) {
      // Overdue stream check revival
      return 1;
    } else {
      // Early check (<25 days) maintains the current streak
      return Math.max(1, currentStreak);
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((listener) => listener());
  }

  public getStreams(): Stream[] {
    return [...this.streams];
  }

  public getStream(streamId: string): Stream | undefined {
    return this.streams.find((s) => s.id === streamId);
  }

  public getObservationsForStream(streamId: string): ObservationRecord[] {
    return this.observations.filter((o) => o.streamId === streamId);
  }

  /**
   * Submits a fresh 5-question stream observation.
   * Expects: streamId (string) and observation data payload.
   * Updates stream to GREEN status, sets next due date 30 days out, and updates the revisit streak.
   */
  public addObservation(streamId: string, data: ObservationData): Stream {
    const stream = this.streams.find((s) => s.id === streamId);
    if (!stream) {
      throw new Error(`Stream with id ${streamId} not found`);
    }

    const nowIso = new Date().toISOString();
    const thirtyDaysFromNowIso = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

    // 1. Calculate streak
    const newStreak = this.computeUpdatedStreak(stream.revisitStreak, stream.lastCheckedDate, nowIso);

    // 2. Turn stream GREEN and update metadata
    stream.status = 'green';
    stream.lastCheckedDate = nowIso;
    stream.nextDueDate = thirtyDaysFromNowIso;
    stream.revisitStreak = newStreak;
    stream.totalObservations += 1;

    // 3. Record the observation
    const newRecord: ObservationRecord = {
      id: `obs-${Date.now()}`,
      streamId,
      timestamp: nowIso,
      data,
    };
    this.observations.unshift(newRecord);

    // 4. Persist and notify UI subscribers
    this.saveToStorage();
    this.notify();

    return stream;
  }
}

export const store = new StreamStore();
