import { StreamStatus } from '../../types/stream';

/**
 * Streaks in StreamKeeper are specifically designed around ecological cadences:
 * Streak = on-time rechecks (~every 30 days), NOT daily opens.
 * 
 * - An on-time check occurs between 25 and 45 days after the previous check.
 * - An early check (< 25 days) keeps the stream fresh and preserves the streak.
 * - An overdue check (> 45 days) revives a red/stale stream back to Green, restarting the streak at 1.
 */

export const ON_TIME_MIN_DAYS = 25;
export const ON_TIME_MAX_DAYS = 45;
export const DUE_CYCLE_DAYS = 30;

export function getFreshnessStatus(lastCheckedDateIso: string): StreamStatus {
  if (!lastCheckedDateIso) return 'red';
  const diffDays = Math.floor((Date.now() - new Date(lastCheckedDateIso).getTime()) / (1000 * 60 * 60 * 24));
  if (diffDays <= DUE_CYCLE_DAYS) return 'green';
  if (diffDays <= ON_TIME_MAX_DAYS) return 'amber';
  return 'red';
}

export function formatRelativeDays(isoDate: string): string {
  const diffDays = Math.round((Date.now() - new Date(isoDate).getTime()) / (1000 * 60 * 60 * 24));
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 0) return `In ${Math.abs(diffDays)} days`;
  return `${diffDays} days ago`;
}

export function formatReadableDate(isoDate: string): string {
  return new Date(isoDate).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}
