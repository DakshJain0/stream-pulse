import React, { useState } from 'react';
import { Stream, ObservationData } from '../../types/stream';
import { store } from '../../store/streamStore';
import { STREAM_CHECK_QUESTIONS } from './questions';

interface StreamCheckWizardProps {
  stream: Stream;
  onSuccess: (updatedStream: Stream) => void;
  onCancel: () => void;
}

export const StreamCheckWizard: React.FC<StreamCheckWizardProps> = ({
  stream,
  onSuccess,
  onCancel,
}) => {
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [answers, setAnswers] = useState<Partial<ObservationData>>({
    waterAppearance: '',
    streamBanks: '',
    flowLevel: '',
    additionalObservation: '',
    overallRating: 0,
    notes: '',
  });
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const totalSteps = STREAM_CHECK_QUESTIONS.length;
  const currentQuestion = STREAM_CHECK_QUESTIONS[currentStep];

  const handleSelectOption = (value: string | number) => {
    setValidationError(null);
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: value,
    }));
  };

  const isCurrentStepAnswered = (): boolean => {
    const key = currentQuestion.id as keyof ObservationData;
    const value = answers[key];
    if (key === 'overallRating') {
      return typeof value === 'number' && value >= 1 && value <= 5;
    }
    return typeof value === 'string' && value.trim().length > 0;
  };

  const handleNext = () => {
    if (!isCurrentStepAnswered()) {
      setValidationError('Please select an option to continue to the next screen.');
      return;
    }

    setValidationError(null);
    if (currentStep < totalSteps - 1) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    setValidationError(null);
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleSubmit = async () => {
    if (!isCurrentStepAnswered()) {
      setValidationError('Please select an overall stream rating before submitting.');
      return;
    }

    setIsSubmitting(true);
    try {
      const observationPayload: ObservationData = {
        waterAppearance: answers.waterAppearance || 'Clear',
        streamBanks: answers.streamBanks || 'Stable & Vegetated',
        flowLevel: answers.flowLevel || 'Normal Baseflow',
        additionalObservation: answers.additionalObservation || 'Natural & Wildlife Present',
        overallRating: Number(answers.overallRating) || 5,
        notes: answers.notes || '',
      };

      // Explicit user requirement: Call store.addObservation() on submit
      const updatedStream = store.addObservation(stream.id, observationPayload);

      // Trigger success callback (displays "Your stream just turned green")
      onSuccess(updatedStream);
    } catch (err) {
      setValidationError(err instanceof Error ? err.message : 'Failed to record stream observation.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const progressPercent = Math.round(((currentStep + 1) / totalSteps) * 100);

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 text-slate-900 pb-24">
      {/* Sticky Mobile Wizard Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 py-3 shadow-xs">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onCancel}
              className="p-1.5 -ml-1.5 text-slate-500 hover:text-slate-900 rounded-full hover:bg-slate-100 transition"
              aria-label="Cancel stream check"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <div>
              <div className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-700">
                Stream-Check Wizard
              </div>
              <h1 className="text-sm font-bold text-slate-900 truncate max-w-[210px]">
                {stream.name}
              </h1>
            </div>
          </div>

          {/* Progress Badge */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-black px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
              Screen {currentStep + 1} of {totalSteps}
            </span>
          </div>
        </div>

        {/* Visual Progress Bar */}
        <div className="max-w-md mx-auto mt-2.5 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-emerald-600 transition-all duration-300 ease-out rounded-full"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </header>

      {/* Main Screen Content */}
      <main className="flex-1 max-w-md w-full mx-auto px-4 pt-5 pb-8">
        {/* Screen Header & Plain-Language Question */}
        <div className="mb-5">
          <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">
            {currentQuestion.category}
          </span>
          <h2 className="text-xl font-extrabold text-slate-900 mt-0.5 sm:text-2xl leading-snug">
            {currentQuestion.title}
          </h2>
          <p className="text-sm font-medium text-slate-700 mt-1">
            {currentQuestion.plainLanguagePrompt}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">
            {currentQuestion.subtitle}
          </p>
        </div>

        {/* Question Options */}
        <div className="space-y-3">
          {currentQuestion.options.map((opt) => {
            const isSelected = answers[currentQuestion.id as keyof ObservationData] === opt.value;
            return (
              <button
                key={String(opt.value)}
                type="button"
                onClick={() => handleSelectOption(opt.value)}
                className={`w-full text-left p-4 rounded-2xl border-2 transition-all duration-150 flex items-start gap-3.5 select-none ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50/80 shadow-md ring-2 ring-emerald-500/20'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/60 shadow-xs'
                }`}
              >
                <span className="text-2xl pt-0.5 shrink-0">{opt.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className={`text-sm font-bold ${isSelected ? 'text-emerald-950' : 'text-slate-900'}`}>
                      {opt.label}
                    </span>
                    <span
                      className={`h-5 w-5 rounded-full border flex items-center justify-center shrink-0 ${
                        isSelected
                          ? 'border-emerald-600 bg-emerald-600 text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {isSelected && (
                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    {opt.description}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Optional Notes on Screen 5 */}
        {currentStep === totalSteps - 1 && (
          <div className="mt-5 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
            <label htmlFor="notes" className="block text-xs font-bold text-slate-800 mb-1">
              Field Notes or Observations (Optional)
            </label>
            <textarea
              id="notes"
              rows={2}
              value={answers.notes}
              onChange={(e) => setAnswers({ ...answers, notes: e.target.value })}
              placeholder="e.g. Fallen branch near outfall, raccoon tracks observed..."
              className="w-full rounded-xl border border-slate-300 p-2.5 text-xs sm:text-sm focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 bg-slate-50"
            />
          </div>
        )}

        {/* Validation Warning Alert */}
        {validationError && (
          <div className="mt-4 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-semibold flex items-center gap-2">
            <svg className="w-4 h-4 text-amber-600 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <span>{validationError}</span>
          </div>
        )}
      </main>

      {/* Sticky Bottom Actions Bar (Mobile First) */}
      <footer className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-md border-t border-slate-200 p-3 z-40">
        <div className="max-w-md mx-auto flex items-center gap-3">
          {/* Back Button */}
          <button
            type="button"
            onClick={handleBack}
            disabled={currentStep === 0}
            className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm border transition ${
              currentStep === 0
                ? 'border-slate-200 text-slate-300 bg-slate-50 cursor-not-allowed'
                : 'border-slate-300 text-slate-700 bg-white hover:bg-slate-50 active:scale-98'
            }`}
          >
            Back
          </button>

          {/* Next / Submit Button */}
          {currentStep < totalSteps - 1 ? (
            <button
              type="button"
              onClick={handleNext}
              className="flex-2 py-3 px-5 rounded-xl font-bold text-xs sm:text-sm text-white bg-emerald-600 shadow-md shadow-emerald-600/20 hover:bg-emerald-700 active:scale-98 transition flex items-center justify-center gap-1.5"
            >
              <span>Next Question</span>
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="flex-2 py-3 px-5 rounded-xl font-bold text-xs sm:text-sm text-white bg-emerald-600 shadow-lg shadow-emerald-600/30 hover:bg-emerald-700 active:scale-98 transition flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <span className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Submitting...</span>
                </>
              ) : (
                <>
                  <span>Submit Stream-Check</span>
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                </>
              )}
            </button>
          )}
        </div>
      </footer>
    </div>
  );
};
