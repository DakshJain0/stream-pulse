import React, { useState } from 'react';
import { Stream } from './types/stream';
import { MyStreams } from './features/streaks';
import { StreamCheckWizard, CheckSuccessModal } from './features/check';

export const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<'my-streams' | 'wizard'>('my-streams');
  const [activeStream, setActiveStream] = useState<Stream | null>(null);
  const [successStream, setSuccessStream] = useState<Stream | null>(null);

  const handleStartCheck = (stream: Stream) => {
    setActiveStream(stream);
    setCurrentView('wizard');
  };

  const handleWizardSuccess = (updatedStream: Stream) => {
    setCurrentView('my-streams');
    setActiveStream(null);
    setSuccessStream(updatedStream);
  };

  const handleCloseWizard = () => {
    setActiveStream(null);
    setCurrentView('my-streams');
  };

  return (
    <div className="min-h-screen bg-slate-100 font-sans antialiased text-slate-900">
      {/* Route: My Streams Dashboard (Adopted sites, next check due, streaks) */}
      {currentView === 'my-streams' && (
        <MyStreams onSelectStreamToCheck={handleStartCheck} />
      )}

      {/* Route: 5-Screen Stream Check Wizard */}
      {currentView === 'wizard' && activeStream && (
        <StreamCheckWizard
          stream={activeStream}
          onSuccess={handleWizardSuccess}
          onCancel={handleCloseWizard}
        />
      )}

      {/* Mandatory celebration modal: 'Your stream just turned green' */}
      {successStream && (
        <CheckSuccessModal
          stream={successStream}
          onClose={() => setSuccessStream(null)}
        />
      )}
    </div>
  );
};

export default App;
