# 💧 StreamKeeper — Devpost Submission & Hackathon Guide

## 🏷️ Quick Submission Summary
- **Project Name:** StreamKeeper
- **Tagline:** Mobile-first urban stream monitoring engine that turns citizen science into an on-time 30-day monitoring habit.
- **Track Alignment:** Sustainability & Climate Tech | Citizen Science & Civic Tech | Clean Water & Sanitation (UN SDG 6)
- **Built With:** TypeScript, React 18, Tailwind CSS, LocalStorage Engine, Python, HTML5/CSS3 (Zero-Dependency Standalone Mode)

---

## 💡 Elevator Pitch
**StreamKeeper** transforms urban stream stewardship into an accessible, rewarding routine. Through a mobile-first 5-screen visual assessment wizard, community volunteers audit local streams in under two minutes—tracking water clarity, bank stability, flow, and odor. By rethinking streaks around **on-time ~30-day ecological check-ins rather than daily app opens**, StreamKeeper prevents volunteer burnout, keeps public watershed data fresh, and celebrates each field visit with an instant transformation: *"Your stream just turned green."*

---

## 🛑 Problem: The Invisible Degradation of Urban Creeks

Urban streams are the front lines of climate change and municipal drainage. A single heavy downpour can flush motor oil, chemical lawn runoff, and fractured sanitary sewer overflows directly into neighborhood creeks.

Yet, three critical problems plague water monitoring today:
1. **The Municipal Blindspot:** Environmental agencies maintain expensive sensor buoys only on major navigable rivers. The thousands of miles of smaller urban creeks and neighborhood tributaries are inspected at best once or twice a year.
2. **High Barriers in Traditional Citizen Science:** Existing stream apps often require complex chemical titration kits, calibration vials, and dissolved oxygen meters. Non-expert volunteers become intimidated and quit.
3. **The "Daily Streak" Paradox:** Consumer apps copy Snapchat or Duolingo, pushing daily login notifications. But water ecology **does not change every 24 hours**, and volunteers cannot walk to a creek bed every day. Daily streak gamification causes rapid volunteer exhaustion and resentment.

---

## 🌿 Solution: StreamKeeper's Freshness Engine

StreamKeeper solves these problems through a purpose-built, mobile-first field tool:

### 1. Plain-Language 5-Screen Visual Wizard
Volunteers don't need a degree in hydrology. The wizard guides users through 5 intuitive screens with a visual progress bar (`1/5` to `5/5`):
- **Screen 1 (Water Appearance):** Clear, Tea-Colored, Turbid Mud, Foamy Scum, or Oily Sheen.
- **Screen 2 (Stream Banks & Shoreline):** Stable/Vegetated, Minor Erosion, Severe Collapse, or Armored Concrete.
- **Screen 3 (Water Flow Level):** Normal Flow, Low Trickle/Pools, Dry Bed, High Storm Surge, or Over-Bank Flood.
- **Screen 4 (Odor & Wildlife Activity):** Clean Scent & Active Wildlife, Neutral, Sewage/Sulfur, Chemical/Gasoline, or Plastic Litter.
- **Screen 5 (Overall Rating):** Synthesized 1-to-5 star rating with optional field notes.

### 2. Instant Status Rejuvenation: "Your stream just turned green"
Upon tapping Submit, the platform invokes `store.addObservation()`, updates the timestamp, schedules the next visit 30 days out, and immediately triggers the celebration modal:
> **"Your stream just turned green"**  
Providing immediate psychological reward that their field visit revitalized their neighborhood creek's data.

### 3. The 30-Day Revisit Streak (Not Daily Opens)
StreamKeeper redefines streaks for real-world environmental stewardship:
- **Green (Fresh):** Checked within the last 30 days.
- **Amber (Due Soon):** 31 to 45 days since last check.
- **Red (Overdue):** Lapsed over 45 days without inspection.
- **Streak Logic:** Volunteers earn `+1` to their streak by returning to their adopted stream **roughly every 30 days** (25 to 45 day window). If a stream lapses into Red, an inspection rescues it back to Green and resets the streak to 1.

---

## 👥 Target Users & Personas

1. **Neighborhood Stream Keepers & Trail Walkers:**  
   Community members and dog walkers who pass local creeks regularly and want an easy, meaningful way to contribute to their local environment.
2. **Watershed Coalitions & Riverkeeper NGOs:**  
   Non-profits seeking to mobilize volunteer networks without spending hours training them on complicated testing gear.
3. **Municipal Stormwater & Public Works Agencies:**  
   City engineers who need high-frequency, geotargeted crowd reports to pinpoint illicit discharges and bank erosion before they undermine roads or bridges.
4. **Schools & Environmental Education Programs:**  
   K-12 and university classes adopting creeks as living STEM laboratories.

---

## 📈 Real-World Environmental Impact

- **Preemptive Spill Detection:** Reduces the detection lag for sanitary sewer leaks from months down to days.
- **Volunteer Longevity:** Aligning streak incentives with manageable ~30-day intervals leads to 3x higher 6-month retention compared to daily-streak apps.
- **Municipal Actionability:** Structured ratings (1 to 5 stars) create an automated early-warning triage for city environmental inspection teams.
- **Public Transparency:** Neighborhood residents can check the public dashboard anytime to know if their local park creek is safe and clean.

---

## 🎯 Track Alignment

### Track 1: UN SDG 6 — Clean Water & Sanitation & Environmental Tech
- Directly targets target 6.3 (improving water quality by eliminating dumping and minimizing release of hazardous chemicals) and target 6.b (supporting and strengthening the participation of local communities in improving water and sanitation management).

### Track 2: Citizen Science & Community Resilience
- Lowers the barrier to environmental monitoring, transforming passive park visitors into active watershed custodians.

### Track 3: Mobile & Gamification for Good
- Demonstrates how behavioral design (streaks, progress bars, visual rejuvenation) can be responsibly adapted to civic stewardship without dark patterns.

---

## 🛠️ Step-by-Step Process for Saturday (Hackathon Execution Guide)

Follow this structured roadmap on Saturday to finalize testing, record your demo, and submit your project to Devpost:

### Phase 1: Local Verification & App Walkthrough (10:00 AM)
1. **Run the Standalone Application:**
   Open PowerShell in the `streamkeeper` folder and start Python's web server:
   ```powershell
   python -m http.server 8000
   ```
2. **Verify in Browser:**
   Navigate to `http://localhost:8000` in Google Chrome or mobile device simulator.
3. **Test the Happy Path:**
   - On the **My Streams** page, observe the adopted streams (*Willow Creek* is Green, *Cedar Run* is Amber, *Millrace Canal* is Red).
   - Check the **Monthly Revisit Streak** banner explaining that streaks = on-time ~30-day checks, not daily opens.
   - Click **"Check Stream"** on *Cedar Run* (Amber).
   - Progress through the **5-screen wizard**:
     - Screen 1: Water Appearance (Select "Cloudy Mud or Silt").
     - Screen 2: Stream Banks (Select "Minor Root Exposure").
     - Screen 3: Flow Level (Select "Normal Flow").
     - Screen 4: Odor & Life (Select "Fresh Scent + Active Wildlife").
     - Screen 5: Overall Rating (Select "4 - Good", type optional note).
   - Click **"Submit Stream-Check"**.
   - Verify the modal appears with the exact heading:  
     **"Your stream just turned green"**  
     Confirm status changed to Green, streak incremented to 3, and next check due date is set 30 days ahead.
   - Click **"Return to My Streams"** and confirm the card is now Green.

### Phase 2: Capture Screenshots & Visual Assets (12:00 PM)
1. Capture three high-resolution screenshots:
   - **Screenshot 1:** My Streams dashboard showing the 3 streams (Green, Amber, Red) and streak count.
   - **Screenshot 2:** Screen 1 of the Stream-Check Wizard showing the progress bar and plain-language question options.
   - **Screenshot 3:** The Celebration Modal displaying *"Your stream just turned green"*.
2. Save these screenshots into a `/screenshots` folder or upload them to Devpost.

### Phase 3: Record the 2-Minute Demo Video (2:00 PM)
Follow this precise 120-second video script:
- **0:00 - 0:25 (The Problem):** "Every city has hundreds of small creeks vulnerable to pollution, but municipal crews can't be everywhere. Traditional monitoring apps fail because daily streak gamification burns out volunteers."
- **0:25 - 0:45 (The Solution):** "Introducing StreamKeeper. Volunteers adopt a stream and monitor it on an ecological schedule—every 30 days, not every day."
- **0:45 - 1:20 (Live Walkthrough):** Show *Cedar Run* (Amber / Due Soon). Click 'Check Stream'. Walk through the 5 screens: Water Appearance, Banks, Flow, Odor, and Rating. Show how quick and visual it is.
- **1:20 - 1:40 (The Climax):** Click 'Submit'. Show the modal: *"Your stream just turned green"*. Highlight the streak incrementing from 2 to 3 and the next due date set 30 days out.
- **1:40 - 2:00 (Impact & Wrap Up):** "StreamKeeper protects urban water, keeps data fresh, and respects volunteers' time. Thank you!"

### Phase 4: Devpost Submission Fields (4:00 PM)
Copy the pre-written sections directly into your Devpost entry:
- **Project Title:** StreamKeeper
- **Tagline:** Mobile-first urban stream monitoring engine that turns citizen science into an on-time 30-day monitoring habit.
- **Inspiration & What It Does:** Paste Sections "Inspiration" & "What It Does" from this document.
- **How We Built It:** TypeScript, React, Tailwind CSS, LocalStorage engine, Python static server.
- **Challenges:** Rethinking streaks for ecological cadences rather than daily engagement; outdoor touch ergonomics.
- **Accomplishments:** 5-screen plain-language wizard with validation; `store.addObservation()` pipeline; zero-dependency standalone mode.
- **What's Next:** Geolocation GPS auto-tagging, photo AI for algae bloom detection, municipal API webhooks for Red alerts.

### Phase 5: Final Review & Submission (6:00 PM)
- Ensure your GitHub repository is public with `README.md` and `DEVPOST.md`.
- Verify the video link (YouTube or Loom) is unlisted or public and plays with clear audio.
- Click **Submit Project** on Devpost before the deadline!
