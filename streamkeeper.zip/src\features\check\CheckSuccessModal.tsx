import React from 'react';
import { Stream } from '../../types/stream';

interface CheckSuccessModalProps {
  stream: Stream;
  onClose: () => void;
}

export const CheckSuccessModal: React.FC<CheckSuccessModalProps> = ({ stream, onClose }) => {
  const formattedNextDue = new Date(stream.nextDueDate).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-sm overflow-hidden bg-white rounded-3xl shadow-2xl border border-emerald-100 p-6 text-center">
        {/* Animated Celebration Droplet */}
        <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100 ring-8 ring-emerald-50">
          <svg className="w-10 h-10 text-emerald-600 animate-bounce" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
          </svg>
        </div>

        {/* Exact required headline */}
        <h2 className="text-2xl font-black text-slate-900 tracking-tight sm:text-3xl">
          Your stream just turned green
        </h2>

        <p className="mt-2 text-xs sm:text-sm text-slate-600">
          You just checked <span className="font-bold text-slate-800">{stream.name}</span> and revitalized its community freshness score.
        </p>

        {/* Freshness Status Card */}
        <div className="mt-5 rounded-2xl bg-emerald-50/80 border border-emerald-200 p-4 text-left space-y-2.5">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="text-emerald-900 uppercase tracking-wider text-[10px]">Stream Status</span>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-600 px-2.5 py-0.5 text-xs font-bold text-white shadow-xs">
              <span className="h-2 w-2 rounded-full bg-white animate-pulse" />
              Green • Fresh
            </span>
          </div>

          <div className="flex items-center justify-between text-xs pt-1.5 border-t border-emerald-100">
            <span className="text-slate-600 font-medium">Revisit Streak:</span>
            <span className="font-extrabold text-emerald-800 flex items-center gap-1">
              🔥 {stream.revisitStreak} On-Time Checks
            </span>
          </div>

          <div className="flex items-center justify-between text-xs pt-1.5 border-t border-emerald-100">
            <span className="text-slate-600 font-medium">Next Check Due:</span>
            <span className="font-bold text-slate-900">{formattedNextDue}</span>
          </div>
        </div>

        {/* Streak Explainer Reminder */}
        <p className="mt-3.5 text-[11px] text-slate-500 leading-snug">
          💡 <strong>Streak reminder:</strong> Waterways need periodic, not daily, check-ins. Your next check is due in ~30 days to maintain your streak!
        </p>

        {/* Action Button */}
        <button
          onClick={onClose}
          className="mt-5 w-full rounded-2xl bg-emerald-600 py-3.5 px-4 text-center font-bold text-sm text-white shadow-lg shadow-emerald-600/25 transition hover:bg-emerald-700 active:scale-98 focus:outline-none focus:ring-2 focus:ring-emerald-500"
        >
          Return to My Streams
        </button>
      </div>
    </div>
  );
};
