// StreamKeeper Data Types and Interfaces

export type StreamStatus = 'green' | 'amber' | 'red';

export interface ObservationData {
  waterAppearance: string;
  streamBanks: string;
  flowLevel: string;
  additionalObservation: string;
  overallRating: number; // 1 to 5
  notes?: string;
  photoUrl?: string;
}

export interface ObservationRecord {
  id: string;
  streamId: string;
  timestamp: string; // ISO date string
  data: ObservationData;
}

export interface Stream {
  id: string;
  name: string;
  location: string;
  watershed: string;
  status: StreamStatus;
  lastCheckedDate: string; // ISO date string
  nextDueDate: string;     // ISO date string (~30 days after last check)
  revisitStreak: number;   // Number of consecutive on-time 30-day checks
  totalObservations: number;
}
