import React, { useState, useEffect } from 'react';
import { Stream, StreamStatus } from '../../types/stream';
import { store } from '../../store/streamStore';
import { formatRelativeDays, formatReadableDate } from './streakUtils';

interface MyStreamsProps {
  onSelectStreamToCheck: (stream: Stream) => void;
}

export const MyStreams: React.FC<MyStreamsProps> = ({ onSelectStreamToCheck }) => {
  const [streams, setStreams] = useState<Stream[]>(store.getStreams());
  const [filter, setFilter] = useState<'all' | 'needs-check' | 'green'>('all');

  useEffect(() => {
    // Subscribe to stream store updates
    const unsubscribe = store.subscribe(() => {
      setStreams(store.getStreams());
    });
    return unsubscribe;
  }, []);

  const getStatusBadge = (status: StreamStatus) => {
    switch (status) {
      case 'green':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            Green • Fresh
          </span>
        );
      case 'amber':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">
            <span className="h-2 w-2 rounded-full bg-amber-500" />
            Amber • Due Soon
          </span>
        );
      case 'red':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-200">
            <span className="h-2 w-2 rounded-full bg-rose-500 animate-ping" />
            Red • Overdue
          </span>
        );
    }
  };

  const filteredStreams = streams.filter((stream) => {
    if (filter === 'needs-check') return stream.status === 'amber' || stream.status === 'red';
    if (filter === 'green') return stream.status === 'green';
    return true;
  });

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 py-3.5 shadow-xs">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white text-lg font-black shadow-sm">
              💧
            </div>
            <div>
              <h1 className="text-base font-black text-slate-900 tracking-tight leading-tight">StreamKeeper</h1>
              <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider">Urban Stream Freshness</span>
            </div>
          </div>
          <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200">
            {streams.length} Adopted Sites
          </span>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-md mx-auto px-4 pt-4 space-y-4">
        {/* Streak Explainer Banner */}
        <div className="rounded-2xl bg-gradient-to-r from-emerald-950 via-teal-900 to-slate-900 text-white p-4 shadow-md relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-lg">🔥</span>
              <h2 className="text-xs font-black uppercase tracking-wider text-emerald-300">
                Monthly Revisit Streak
              </h2>
            </div>
            <p className="text-xs text-emerald-100 leading-relaxed">
              <strong>Streak = on-time rechecks (~every 30 days), NOT daily opens.</strong> Local stream ecosystems don't need daily checks; they rely on consistent monthly observations to detect seasonal pollution surges and bank collapses.
            </p>
          </div>
          {/* Subtle water wave background motif */}
          <div className="absolute -right-4 -bottom-6 opacity-10 text-8xl select-none pointer-events-none">
            🌊
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 rounded-xl">
          <button
            onClick={() => setFilter('all')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition ${
              filter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All ({streams.length})
          </button>
          <button
            onClick={() => setFilter('needs-check')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition ${
              filter === 'needs-check'
                ? 'bg-white text-amber-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Needs Check ({streams.filter((s) => s.status !== 'green').length})
          </button>
          <button
            onClick={() => setFilter('green')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition ${
              filter === 'green'
                ? 'bg-white text-emerald-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Fresh ({streams.filter((s) => s.status === 'green').length})
          </button>
        </div>

        {/* Adopted Streams Cards */}
        <div className="space-y-3.5">
          {filteredStreams.map((stream) => {
            const isDueOrOverdue = stream.status === 'amber' || stream.status === 'red';

            return (
              <div
                key={stream.id}
                className={`rounded-2xl border bg-white p-4 shadow-xs transition-all duration-200 hover:shadow-md ${
                  stream.status === 'red'
                    ? 'border-rose-200 ring-1 ring-rose-100'
                    : stream.status === 'amber'
                    ? 'border-amber-200'
                    : 'border-slate-200/80 hover:border-emerald-300'
                }`}
              >
                {/* Top Row: Stream Name & Status */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 leading-snug">
                      {stream.name}
                    </h3>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <svg className="w-3.5 h-3.5 text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                      {stream.location}
                    </p>
                  </div>
                  <div>{getStatusBadge(stream.status)}</div>
                </div>

                {/* 3 Core Stream Freshness Metrics */}
                <div className="mt-3.5 grid grid-cols-3 gap-2 py-2.5 px-3 rounded-xl bg-slate-50 border border-slate-100 text-center">
                  {/* Metric 1: Last Checked */}
                  <div>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Last Check
                    </span>
                    <span className="block text-xs font-bold text-slate-800 mt-0.5">
                      {formatRelativeDays(stream.lastCheckedDate)}
                    </span>
                    <span className="text-[10px] text-slate-400 block truncate">
                      {formatReadableDate(stream.lastCheckedDate)}
                    </span>
                  </div>

                  {/* Metric 2: Next Due Date */}
                  <div className="border-x border-slate-200">
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Next Due Date
                    </span>
                    <span
                      className={`block text-xs font-bold mt-0.5 ${
                        stream.status === 'red'
                          ? 'text-rose-600'
                          : stream.status === 'amber'
                          ? 'text-amber-600'
                          : 'text-emerald-700'
                      }`}
                    >
                      {formatReadableDate(stream.nextDueDate)}
                    </span>
                    <span className="text-[10px] text-slate-400 block truncate">
                      (~30-day cycle)
                    </span>
                  </div>

                  {/* Metric 3: Current Streak */}
                  <div>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Current Streak
                    </span>
                    <span className="block text-xs font-black text-orange-600 mt-0.5">
                      🔥 {stream.revisitStreak}
                    </span>
                    <span className="text-[10px] text-slate-400 block truncate">
                      On-Time Checks
                    </span>
                  </div>
                </div>

                {/* Action Row */}
                <div className="mt-3.5 pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                  <div className="text-[11px] text-slate-500 font-medium">
                    {stream.totalObservations} inspections recorded
                  </div>
                  <button
                    type="button"
                    onClick={() => onSelectStreamToCheck(stream)}
                    className={`py-2 px-4 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-98 ${
                      isDueOrOverdue
                        ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-600/20'
                        : 'bg-slate-900 text-white hover:bg-slate-800'
                    }`}
                  >
                    <span>Check Stream</span>
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
};
