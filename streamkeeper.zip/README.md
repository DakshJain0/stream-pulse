# 💧 StreamKeeper

> **Mobile-First Urban Stream Monitoring & Freshness Engine**  
> Empowering citizen science volunteers to adopt local stream reaches, complete visual health assessments, and maintain on-time monthly revisit streaks.

[![License: MIT](https://img.shields.io/badge/License-MIT-emerald.svg)](LICENSE)
[![Protocol](https://img.shields.io/badge/Protocol-EPA%20Visual%20Stream%20Assessment-blue.svg)](#-the-5-screen-stream-check-protocol)
[![Streak Model](https://img.shields.io/badge/Streak%20Model-Monthly%20Cadence%20(~30d)-orange.svg)](#-monthly-revisit-streak-not-daily-opens)

---

## 📖 Table of Contents
1. [What It Is](#-what-it-is)
2. [The 5-Screen Stream-Check Protocol](#-the-5-screen-stream-check-protocol)
3. [Monthly Revisit Streak (Not Daily Opens)](#-monthly-revisit-streak-not-daily-opens)
4. [What is Real vs. Synthetic Data](#-what-is-real-vs-synthetic-data)
5. [Screenshots & UI Walkthrough](#-screenshots--ui-walkthrough)
6. [How to Run](#-how-to-run)
7. [Project Architecture & Folders](#-project-architecture--folders)
8. [Devpost & Hackathon Pitch](#-devpost--hackathon-pitch)

---

## 🌊 What It Is

Urban waterways are prone to sudden ecological stress—from illicit stormwater runoff and industrial chemical discharge to sewer line fractures and stream bank collapse. While municipal governments maintain intermittent testing stations at major river points, **hundreds of smaller urban tributaries and neighborhood creeks remain unmonitored for months at a time.**

**StreamKeeper** turns community volunteers and trail walkers into front-line guardians of their watersheds. Volunteers adopt specific stream segments ("reaches") and use a rapid, accessible 5-screen visual assessment wizard directly on their mobile phones while standing on the stream bank.

### Core Philosophy:
- **Zero Bio-Degree Required**: All questions are formulated in plain, accessible language with intuitive icons and sensory descriptions.
- **Ecologically Grounded Streaks**: Traditional apps spam users for daily logins. StreamKeeper rewards **on-time ~30-day monitoring intervals**, preventing volunteer burnout while keeping public water data fresh.
- **Instant Community Feedback**: The moment an observation is submitted via `store.addObservation()`, the stream status visually flips from Amber/Red back to **Green** with the celebration banner: **"Your stream just turned green"**.

---

## 📋 The 5-Screen Stream-Check Protocol

StreamKeeper adapts the visual assessment methodologies of the **EPA Volunteer Stream Monitoring Guidelines**, **CreekWatch**, and the **Waterkeeper Alliance** into 5 streamlined, sequential mobile screens:

| Screen # | Metric | Plain-Language Question | Core Options Evaluated |
|:---:|:---|:---|:---|
| **Screen 1** | **Water Appearance** | *"What does the stream water look like today?"* | 💧 Clear & Transparent, 🍂 Tea-Colored (Natural Tannins), 🌫️ Cloudy Mud/Silt, 🧼 Foam or Green Scum, ⛽ Oily/Rainbow Sheen |
| **Screen 2** | **Stream Banks & Shoreline** | *"How healthy and stable are the stream banks?"* | 🌿 Stable & Vegetated, 🌱 Minor Erosion/Exposed Roots, ⚠️ Severe Bank Collapse, 🧱 Concrete/Riprap Channel |
| **Screen 3** | **Water Flow Level** | *"How fast and high is the water running?"* | 🌊 Normal Baseflow, 🪨 Low Trickle/Isolated Pools, ☀️ Dry Streambed, ⚡ Swift Stormflow Surge, 🚨 Over-Bank Flooding |
| **Screen 4** | **Odor & Wildlife Signs** | *"Do you notice any distinct odors or signs of life?"* | 🐟 Fresh Scent + Active Wildlife, 🍃 Neutral / No Smell, 🦨 Sewage/Rotten Eggs, 🧪 Chemical/Fuel/Bleach, 🗑️ Heavy Trash & Debris |
| **Screen 5** | **Overall Rating** | *"What is your overall health rating for this stream today?"* | ⭐ 1 (Very Poor / Alert) to ⭐⭐⭐⭐⭐ 5 (Excellent Pristine Creek) + Optional field notes |

---

## 🔥 Monthly Revisit Streak (Not Daily Opens)

```
       Last Check                                               Overdue Threshold
         (Day 0)                On-Time Revisit Window              (Day 45+)
            │                       [25 to 45 Days]                     │
            ▼                                                           ▼
┌───────────────────────┬───────────────────────────────────┬───────────────────────┐
│     🟢 FRESH          │           🟡 DUE SOON             │       🔴 OVERDUE      │
│   (Days 0 to 30)      │         (Days 31 to 45)           │     (Days 46 and up)  │
└───────────────────────┴───────────────────────────────────┴───────────────────────┘
            │                               │                           │
 Early Recheck (<25d)               On-Time Recheck             Revival Recheck
 Maintains current streak           Streak increments (+1)      Revives stream to Green;
                                                                Restarts streak at 1
```

In social media or gaming apps, a "streak" measures whether you opened the app in consecutive 24-hour periods. **For stream monitoring, daily streaks are scientifically counter-productive and cause volunteer fatigue.**

StreamKeeper re-engineers the streak around the **30-day ecological sampling cycle**:
1. **Fresh Window (Green)**: The first 30 days after an observation is submitted.
2. **Due Soon Window (Amber)**: Between 30 and 45 days after the last check.
3. **Overdue (Red)**: After 45 days without an inspection, the reach decays to "stale".
4. **Streak Calculation Rule**:
   - **On-Time Revisit (25–45 days)**: Streak count increments (`streak + 1`).
   - **Early Revisit (< 25 days)**: Maintains existing streak count while refreshing the 30-day due date.
   - **Revival Revisit (> 45 days)**: Rescues the stream from Red back to Green, restarting the streak at `1` to reward the volunteer for returning to active care.

---

## 🔬 What is Real vs. Synthetic Data

Transparency is vital for civic environmental tools. The table below outlines what represents real scientific protocols versus what is synthetic demo simulation:

| Component | Status | Details & Implementation Rationale |
|:---|:---:|:---|
| **Visual Check Protocol** | **REAL** | The 5 questions, option categories, descriptions, and icon indicators are directly grounded in the **EPA Volunteer Stream Visual Assessment Protocol** and **CreekWatch** field survey parameters. |
| **30-Day Streak Engine** | **REAL** | The algorithmic evaluation window (`25 <= diffDays <= 45`), state progression (`green` ➜ `amber` ➜ `red`), and streak decay/revival mathematics are fully implemented and functional in code. |
| **Observation Schema & State** | **REAL** | Every submission creates a structured `ObservationRecord` with ISO timestamps, question IDs, rating values, optional field notes, and calls `store.addObservation()`. |
| **Adopted Stream Sites** | **SYNTHETIC** | *Willow Creek*, *Cedar Run*, and *Millrace Canal* are synthetic urban test sites configured with realistic geographic descriptions and watershed names. |
| **Seed Timestamps** | **SYNTHETIC** | Initial mock streams are seeded with synthetic elapsed days (12 days ago, 33 days ago, 55 days ago) specifically so judges can observe **Green**, **Amber**, and **Red** states immediately upon launching the app. |
| **Persistence Storage** | **SYNTHETIC** | Runs in browser `localStorage` to allow instant, zero-dependency testing without requiring a live remote GIS database or user authentication setup. |

---

## 📱 Screenshots & UI Walkthrough

### 1. "My Streams" Dashboard (Adopted Sites & Monthly Streak)
```
┌──────────────────────────────────────────────────┐
│  💧 StreamKeeper             [3 Adopted Sites]   │
│  URBAN STREAM FRESHNESS                          │
├──────────────────────────────────────────────────┤
│  🔥 MONTHLY REVISIT STREAK                       │
│  Streak = on-time rechecks (~every 30 days),     │
│  NOT daily opens. Watersheds need reliable       │
│  monthly observations to stay fresh!             │
├──────────────────────────────────────────────────┤
│  [ All (3) ]   [ Needs Check (2) ]   [ Fresh (1) ]
├──────────────────────────────────────────────────┤
│  Cedar Run - Mid Reach        [🟡 Amber • Due Soon]
│  📍 Elmwood Pedestrian Bridge                    │
│  ┌──────────────┬──────────────┬──────────────┐  │
│  │  Last Check  │   Next Due   │Current Streak│  │
│  │ 33 days ago  │ 3 days ago   │  🔥 2 Checks │  │
│  │ (Sep 1, 2026)│(~30-day cycle│  (On-Time)   │  │
│  └──────────────┴──────────────┴──────────────┘  │
│  3 inspections recorded      [ Check Stream ➔ ]  │
└──────────────────────────────────────────────────┘
```

### 2. The 5-Screen Stream-Check Wizard (Screen 1 with Progress Bar)
```
┌──────────────────────────────────────────────────┐
│  ✕  STREAM-CHECK WIZARD        [Screen 1 of 5]   │
│     Cedar Run - Mid Reach                        │
│  [██████████░░░░░░░░░░░░░░░░░░░░░░░░░░] 20%     │
├──────────────────────────────────────────────────┤
│  SCREEN 1 OF 5                                   │
│  Water Appearance                                │
│  What does the stream water look like today?     │
│  Look closely at the water clarity and film.     │
│                                                  │
│  ┌────────────────────────────────────────────┐  │
│  │ 💧 Clear & Transparent                 ( ) │  │
│  │ Pebbles and stream bed easily visible.     │  │
│  └────────────────────────────────────────────┘  │
│  ┌────────────────────────────────────────────┐  │
│  │ 🌫️ Cloudy Mud or Silt                   (•) │  │  <-- Selected
│  │ Suspended sediment making water opaque.    │  │
│  └────────────────────────────────────────────┘  │
│  ┌────────────────────────────────────────────┐  │
│  │ 🧼 Foam or Green Scum                  ( ) │  │
│  │ Persistent bubbles or algae mats.          │  │
│  └────────────────────────────────────────────┘  │
│  ┌────────────────────────────────────────────┐  │
│  │ ⛽ Oily / Rainbow Sheen                 ( ) │  │
│  │ Colorful petroleum film on surface.        │  │
│  └────────────────────────────────────────────┘  │
├──────────────────────────────────────────────────┤
│  [ Back ]                  [ Next Question ➔ ]   │
└──────────────────────────────────────────────────┘
```

### 3. Submission Celebration Modal ("Your stream just turned green")
```
┌──────────────────────────────────────────────────┐
│              ╭────────────────────╮              │
│              │      💧 🎉         │              │
│              ╰────────────────────╯              │
│          Your stream just turned green           │
│                                                  │
│  You just checked Cedar Run - Mid Reach and      │
│  revitalized its community freshness score!      │
│                                                  │
│  ┌────────────────────────────────────────────┐  │
│  │ Stream Status:          🟢 Green • Fresh   │  │
│  │ Revisit Streak:         🔥 3 On-Time Checks│  │
│  │ Next Check Due:         Nov 2, 2026        │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  💡 Streak reminder: Waterways need periodic,    │
│  not daily check-ins. Next check in ~30 days!    │
│                                                  │
│        [ Return to My Streams ]                  │
└──────────────────────────────────────────────────┘
```

---

## 💻 How to Run

StreamKeeper supports two execution environments:

### Option A: Instant Zero-Dependency Standalone Mode (Recommended)
You can run StreamKeeper directly in any web browser without needing `npm` or `node`:

1. Open PowerShell or Terminal in the `streamkeeper` root folder.
2. Start Python's built-in web server:
   ```bash
   python -m http.server 8000
   ```
3. Open `http://localhost:8000` in Google Chrome, Microsoft Edge, Safari, or on your mobile device.

Alternatively, you can directly double-click `index.html` in your file explorer to open it locally.

### Option B: Modern React + TypeScript + Vite
If you have a Node.js development environment:
```bash
npm install
npm run dev
```
Open `http://localhost:5173` to interact with the Vite dev server with hot-module reloading.

---

## 📂 Project Architecture & Folders

The project follows a clean, feature-driven folder architecture:

```
streamkeeper/
├── index.html                       # Zero-dependency, self-contained standalone app
├── package.json                     # React 18, Vite 5, Tailwind CSS config
├── README.md                        # Documentation, protocol guide, real vs synthetic data
├── DEVPOST.md                       # Hackathon Devpost submission copy & weekend step-by-step
└── src/
    ├── App.tsx                      # Root component orchestrating My Streams & Wizard views
    ├── main.tsx                     # React DOM entrypoint
    ├── index.css                    # Tailwind CSS base styles
    ├── types/
    │   └── stream.ts                # TypeScript interfaces (Stream, Observation, Status)
    ├── store/
    │   └── streamStore.ts           # Central StreamStore & store.addObservation() implementation
    ├── features/
    │   ├── check/                   # 5-Screen Stream Check Feature
    │   │   ├── questions.ts         # EPA/CreekWatch 5-screen plain-language questions
    │   │   ├── StreamCheckWizard.tsx # 5-screen wizard with progress bar and validation
    │   │   ├── CheckSuccessModal.tsx # "Your stream just turned green" celebration modal
    │   │   └── index.ts             # Feature barrel export
    │   └── streaks/                 # Monthly Streak & Adopted Streams Feature
    │       ├── MyStreams.tsx        # Adopted streams hub, next due dates, streak indicators
    │       ├── streakUtils.ts       # 30-day streak calculation logic and date helpers
    │       └── index.ts             # Feature barrel export
    └── components/                  # Compatibility re-exports for legacy routes
```

---

## 🏆 Devpost & Hackathon Pitch

A complete, submission-ready Devpost submission text with:
- **Elevator Pitch**
- **Problem Statement**
- **Solution & Innovation**
- **Target Users**
- **Environmental Impact**
- **Track Alignment (SDG 6: Clean Water, Climate Action, Citizen Science)**
- **Saturday Step-by-Step Submission Roadmap**

Can be found in [DEVPOST.md](DEVPOST.md).
